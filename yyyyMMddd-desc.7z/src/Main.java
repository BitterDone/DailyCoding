public class Main {
    public static void main(String[] args) {
        Workload w = new Workload();
        w.l();
    }
}

class Workload {

    public void l() {
        System.out.println("Finished");
    }

}